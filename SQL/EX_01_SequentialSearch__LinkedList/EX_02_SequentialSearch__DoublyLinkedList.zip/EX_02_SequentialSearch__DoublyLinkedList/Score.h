#pragma once
typedef struct tagScore
{
    int    number;
    double score;
} Score;



